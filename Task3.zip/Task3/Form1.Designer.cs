﻿namespace Task3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BubbleSortButton = new Button();
            SearchTextBox = new TextBox();
            SearchButton = new Button();
            NeutrinoInteractionsListBox = new ListBox();
            EditButton = new Button();
            EditTextBox = new TextBox();
            RepopulateList = new Button();
            SuspendLayout();
            // 
            // BubbleSortButton
            // 
            BubbleSortButton.Location = new Point(63, 229);
            BubbleSortButton.Name = "BubbleSortButton";
            BubbleSortButton.Size = new Size(127, 23);
            BubbleSortButton.TabIndex = 1;
            BubbleSortButton.Text = "Bubble Sort";
            BubbleSortButton.UseVisualStyleBackColor = true;
            BubbleSortButton.Click += BubbleSortButton_Click;
            // 
            // SearchTextBox
            // 
            SearchTextBox.Location = new Point(236, 100);
            SearchTextBox.Name = "SearchTextBox";
            SearchTextBox.Size = new Size(341, 23);
            SearchTextBox.TabIndex = 2;
            SearchTextBox.TextChanged += SearchTextBox_TextChanged;
            // 
            // SearchButton
            // 
            SearchButton.Location = new Point(63, 100);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(127, 23);
            SearchButton.TabIndex = 3;
            SearchButton.Text = "SearchButton";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // NeutrinoInteractionsListBox
            // 
            NeutrinoInteractionsListBox.FormattingEnabled = true;
            NeutrinoInteractionsListBox.ItemHeight = 15;
            NeutrinoInteractionsListBox.Location = new Point(236, 165);
            NeutrinoInteractionsListBox.Name = "NeutrinoInteractionsListBox";
            NeutrinoInteractionsListBox.Size = new Size(341, 199);
            NeutrinoInteractionsListBox.TabIndex = 4;
            NeutrinoInteractionsListBox.SelectedIndexChanged += NeutrinoInteractionsListBox_SelectedIndexChanged;
            // 
            // EditButton
            // 
            EditButton.Location = new Point(63, 38);
            EditButton.Name = "EditButton";
            EditButton.Size = new Size(127, 23);
            EditButton.TabIndex = 5;
            EditButton.Text = "EditButton";
            EditButton.UseVisualStyleBackColor = true;
            EditButton.Click += EditButton_Click;
            // 
            // EditTextBox
            // 
            EditTextBox.Location = new Point(236, 38);
            EditTextBox.Name = "EditTextBox";
            EditTextBox.Size = new Size(341, 23);
            EditTextBox.TabIndex = 6;
            EditTextBox.TextChanged += EditTextBox_TextChanged;
            // 
            // RepopulateList
            // 
            RepopulateList.Location = new Point(63, 165);
            RepopulateList.Name = "RepopulateList";
            RepopulateList.Size = new Size(127, 23);
            RepopulateList.TabIndex = 7;
            RepopulateList.Text = "RepopulateList";
            RepopulateList.UseVisualStyleBackColor = true;
            RepopulateList.Click += RepopulateList_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(RepopulateList);
            Controls.Add(EditTextBox);
            Controls.Add(EditButton);
            Controls.Add(NeutrinoInteractionsListBox);
            Controls.Add(SearchButton);
            Controls.Add(SearchTextBox);
            Controls.Add(BubbleSortButton);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button BubbleSortButton;
        private TextBox SearchTextBox;
        private Button SearchButton;
        private ListBox NeutrinoInteractionsListBox;
        private Button EditButton;
        private TextBox EditTextBox;
        private Button RepopulateList;
    }
}