namespace Task3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            PopulateListBox();
        }

        private void PopulateListBox()
        {
            int[] neutrinoNumbers = new int[24];
            Random random = new Random();

            for (int i = 0; i < neutrinoNumbers.Length; i++)
            {
                neutrinoNumbers[i] = random.Next(10, 99);
                NeutrinoInteractionsListBox.Items.Add(neutrinoNumbers[i]);
            }
        }

        private void NeutrinoInteractionsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BubbleSortButton_Click(object sender, EventArgs e)
        {
            BubbleSort();
        }

        private void BubbleSort()
        {
            int[] items = new int[NeutrinoInteractionsListBox.Items.Count];
            for (int i = 0; i < NeutrinoInteractionsListBox.Items.Count; i++)
            {
                items[i] = (int)NeutrinoInteractionsListBox.Items[i];
            }

            for (int i = 0; i < items.Length - 1; i++)
            {
                for (int j = 0; j < items.Length - 1 - i; j++)
                {
                    if (items[j] > items[j + 1])
                    {
                        int temp = items[j];
                        items[j] = items[j + 1];
                        items[j + 1] = temp;
                    }
                }
            }
            NeutrinoInteractionsListBox.Items.Clear();
            foreach (int item in items)
            {
                NeutrinoInteractionsListBox.Items.Add(item);
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            int searchValue;
            if (int.TryParse(SearchTextBox.Text, out searchValue))
            {
                int index = BinarySearch(searchValue);
                if (index != -1)
                {
                    NeutrinoInteractionsListBox.SelectedIndex = index;
                    MessageBox.Show($"number {searchValue} found at index {index}");
                }
                else
                {
                    MessageBox.Show("number not found amigo sorry");
                }
            }
            else
            {
                MessageBox.Show("enter valid number to search");
            }
        }

        private int BinarySearch(int target)
        {
            int left = 0;
            int right = NeutrinoInteractionsListBox.Items.Count - 1;

            while (left <= right)
            {
                int mid = (left + right) / 2;
                int midValue = (int)NeutrinoInteractionsListBox.Items[mid];

                if (midValue == target)
                {
                    return mid;
                }
                else if (midValue < target)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid - 1;
                }
            }
            return -1;
        }
        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void EditTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            int selectedIndex = NeutrinoInteractionsListBox.SelectedIndex;
            if (selectedIndex >= 0)
            {
                int editValue;
                if (int.TryParse(EditTextBox.Text, out editValue))
                {
                    NeutrinoInteractionsListBox.Items[selectedIndex] = editValue;
                    EditTextBox.Clear();
                    MessageBox.Show($"Number at index {selectedIndex} edited to become {editValue}");
                }
                else
                {
                    MessageBox.Show("please select an index to edit my amigo");
                }
            }
            else
            {
                MessageBox.Show("please select an index to edit bro");
            }
        }

        private void RepopulateList_Click(object sender, EventArgs e)
        {
            NeutrinoInteractionsListBox.Items.Clear();
            PopulateListBox();
        }
    }
}