//Lewis Cottrill
//07/09/2023
//ICTPRG440, 437
//Create a rego tracker for a parking garage in winforms

namespace ParkingTracker
{
    public partial class Form1 : Form
    {
        private string filePath = string.Empty; //I initialize a string called filepath, it has an empty string
        private List<string> carRegos = new List<string>(); //I create a variable called carRegos, it is a list of strings
        ToolTip toolTip = new ToolTip(); //I create a tooltip function
        public Form1() //Public functions
        {
            InitializeComponent(); //Winforms inbuilt function to initialize the UI 
            RegoList.DrawMode = DrawMode.OwnerDrawFixed; //Sets the drawing mode to OwnerDrawFixed
            RegoList.DrawItem += RegoList_DrawItem;
            string openFileDefinition = "This button opens a text file";
            toolTip.SetToolTip(OpenFile, openFileDefinition);
            string updateButtonDefinition = "This button updates selected regos, you can make changes to the selected rego using the text box to the right of this button";
            toolTip.SetToolTip(UpdateButton, updateButtonDefinition);
            string addNewDefinition = "This button adds new regos to the list, you can input data in the text box to the right of this button";
            toolTip.SetToolTip(AddNew, addNewDefinition);
            string saveDataDefinition = "This button saves any and all changes to the file";
            toolTip.SetToolTip(SaveData, saveDataDefinition);
            string deleteExistingRegoDefinition = "This button deletes the selected rego in the list";
            toolTip.SetToolTip(DeleteExistingRego, deleteExistingRegoDefinition);
            string tagRegoDefinition = "This button tags a rego with red text and an asterix for identification";
            toolTip.SetToolTip(TagRego, tagRegoDefinition);
            string deleteAllDefinition = "This button deletes everything in the list";
            toolTip.SetToolTip(DeleteAll, deleteAllDefinition);
            string linearSearchDefinition = "This button performs a linear search of the list for a specific rego, input the rego to search in the text box below";
            toolTip.SetToolTip(LinearSearch, linearSearchDefinition);
            string listDefinition = "This is the list box that contains regos";
            toolTip.SetToolTip(RegoList, listDefinition);
            string binarySearchDefinition = "This button performs a binary search of the list for a specific rego, input the rego to search in the text box below";
            toolTip.SetToolTip(BinarySearch, binarySearchDefinition);
        }
        private void RegoList_DoubleClick(object sender, EventArgs e)
        {
            if (RegoList.SelectedIndex >= 0) //If user selects an item in the list
            {
                string selectedItem = RegoList.SelectedItem.ToString(); //This retrieves the text of the currently selected item in the list, and stores it in selectedItem string

                DialogResult result = MessageBox.Show($"Are you sure you want to delete {selectedItem}?", "Confirm Selection",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question); //This outputs a message box asking user if they would like to delete the selected item
               
                if (result == DialogResult.Yes) //If user says yes
                {
                    carRegos.RemoveAt(RegoList.SelectedIndex); //Remove the selected index from the list
                    carRegos.Sort(); //Sort the list
                    UpdateListBox(); //Update the list
                }
            }
        }

        private void OpenFile_Click(object sender, EventArgs e) //This is the open file button function
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog()) //This opens the file dialogue so user can select a text file
            {
                openFileDialog.Title = "Select a text file from the list of text files. only text files can be selected. files other than text files may not be selected. ";
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"; //This filters the files to text files only

                if (openFileDialog.ShowDialog() == DialogResult.OK) //If user opens the file dialogue, selects a text file and selects OK
                {
                    filePath = openFileDialog.FileName; //The file path = the selected file in the file dialogue

                    try 
                    {
                        if (File.Exists(filePath)) //If file exists
                        {
                            carRegos = new List<string>(File.ReadAllLines(filePath)); //carRegos list becomes the contents of the text file
                            carRegos.Sort(); //Sort list
                            UpdateListBox(); //Update list
                        }
                        else
                        {
                            MessageBox.Show("File not found..."); //If file is not found
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("ERROR LOADING! " + ex.Message); //If there is an error
                    }
                }
            }
        }
        private void UpdateListBox() //This updates the contents of the RegoList list box, it clears the list box then adds the items from carRegos list.
                                     //Crucial to visually reflect the changes made to the RegoList list.
        {
            RegoList.Items.Clear(); //Clears items in the RegoList list
            foreach (string rego in carRegos) 
            {
                RegoList.Items.Add(rego); //Repopulates the list with items from the carRegos list
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e) //If the Update button is clicked
        {
            if (RegoList.SelectedIndex >= 0) //If an item is selected in the RegoList list
            {
                string modifiedCarRego = ModifyRegoTextBox.Text; //The text in the ModifyRegoTextBox becomes the string modifiedCarRego

                if (!string.IsNullOrEmpty(modifiedCarRego)) //If the text box is NOT null or empty
                {
                    carRegos[RegoList.SelectedIndex] = modifiedCarRego; //This updates the selected index with the text written in the ModifyRegoTextBox
                    carRegos.Sort();                                    //SelectedIndex of RegoList becomes modifiedCarRego (Text within ModifyRegoTextBox)
                    UpdateListBox();
                    ModifyRegoTextBox.Clear(); //Clear the ModifyRegoTextBox 
                }
            }
        }

        private void AddNew_Click(object sender, EventArgs e) //If the AddNew button is clicked
        {
            string newCarRego = NewRegoTextBox.Text; //The text in the NewRegoTextBox becomes the string newCarRego
            if (!string.IsNullOrWhiteSpace(newCarRego)) //If the NewRegoTextBox is not empty
            {
                carRegos.Add(newCarRego); //Add the new car rego to the carRegos list
                carRegos.Sort(); //Sort the carRegos list
                UpdateListBox(); //Then update the ListBox
                NewRegoTextBox.Clear(); //Clear the NewRegoTextBox
            }
        }

        private void RegoList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RegoList.SelectedIndex >= 0) //If user has selected something in the list
            {
                ModifyRegoTextBox.Text = RegoList.SelectedItem.ToString(); //Make the index selected in the list also appear in the ModifyRegoTextBox text box
            }                                                              //This makes the program more user friendly and less time consuming to use
        }

        private void SaveData_Click(object sender, EventArgs e) //If the SaveData button is clicked
        {
            try
            {
                carRegos.Sort(); //Sort the carRegos list
                File.WriteAllLines(filePath, carRegos); //Write the contents of the list to the text file selected 
                MessageBox.Show("List Saved! "); //Present a message box to the user with information
            }
            catch (Exception ex) //If there is an error saving
            {
                MessageBox.Show("ERROR SAVING! " + ex.Message); //Tell user there is an error saving
            }
        }
        private int saveCounter = 3; //This sets the numerical increments of saved files
        private void SaveAs_Click(object sender, EventArgs e) //If user clicks on SaveAs button
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog()) //This opens the save file dialogue
            {
                saveFileDialog.Title = "Save As";
                saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"; //Only text files are shown

                string defaultFileName = $"Demo_0{saveCounter}.txt"; //This assigns the files a generic name with a variable number
                saveFileDialog.FileName = defaultFileName; //The file name in the SaveAs file dialogue is prefilled 

                if (saveFileDialog.ShowDialog() == DialogResult.OK) //If user selects ok, save the file.
                {
                    string saveFilePath = saveFileDialog.FileName; //The path becomes the directory of the file saved

                    try
                    {
                        File.WriteAllLines(saveFilePath, carRegos); //Write contents of carRegos to the file
                        MessageBox.Show("Data saved to " + saveFilePath);
                        saveCounter++; //Increase increment at the end of the file name to order and identify the file
                    }
                    catch (Exception ex) //If there is an error
                    {
                        MessageBox.Show("Error Saving Data: " + ex.Message);
                    }
                }
            }
        }

        private void DeleteExistingRego_Click(object sender, EventArgs e) //If the DeleteExistingRego button is clicked
        {
            if (RegoList.SelectedIndex >= 0) //If the user has selected something in the list
            {
                carRegos.RemoveAt(RegoList.SelectedIndex); //Remove the selected index from the carRegos list
                UpdateListBox(); //Update the ListBox
                carRegos.Sort(); //Sort the carRegos list
            }
        }

        private void TagRego_Click(object sender, EventArgs e) //If TagRego button is clicked
        {
            if (RegoList.SelectedIndex >= 0) //If user has selected an index greater or equal to 0 in the list (selected anything in the list)
            {
                string selectedItem = RegoList.SelectedItem.ToString(); //This grabs the text of the selected item in the list
                if (selectedItem.EndsWith("*")) //This checks if the item is already ending with *
                {
                    selectedItem = selectedItem.TrimEnd('*'); //If yes, remove the end character *, done individually
                }
                else
                {
                    selectedItem += "*"; //If no, add an * to the end
                }
                carRegos[RegoList.SelectedIndex] = selectedItem; //This updates the carRegos list at the corresponding index with the selectedItem, ensures the
                                                                 //* is reflected in the RegoList list of regos
                UpdateListBox(); //Update the ListBox
            }
        }

        private void DeleteAll_Click(object sender, EventArgs e) //If the DeleteAll button is clicked
        {
            RegoList.Items.Clear(); //Clear all items from RegoList list box
            ModifyRegoTextBox.Clear(); //Clear the ModifyRegoTextBox
            carRegos.Clear(); //Clear the carRegos
            UpdateListBox(); //UpdateListBox
        }

        private void ModifyRegoTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewRegoTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void RegoList_DrawItem(object sender, DrawItemEventArgs e) //This function changes the colour of the text when tagging
        //Ensure DRAWMODE in BEHAVIOUR/PROPERTIES is switched to OwnerDrawVariable (or this function will not work correctly!)
        {
            if (e.Index >= 0 && e.Index < RegoList.Items.Count) //If an index greater or equal to 0 is selected
            {
                e.DrawBackground(); //This is used to draw the background of the item, ensures it is properly painted before the text appearance is customized
                string itemText = RegoList.Items[e.Index].ToString(); //This grabs the text of the item at the selected index, and stores it in the itemText string
                
                if (itemText.EndsWith("*")) //If itemText text ends with an *
                {
                    e.Graphics.DrawString(itemText.TrimEnd(), //This redraws the itemText with red coloured text
                        e.Font, Brushes.Red, e.Bounds);
                }
                else
                {
                    e.Graphics.DrawString(itemText, e.Font, Brushes.Black, e.Bounds); //If the item doesnt end with *, redraw the itemText in black (untagged)
                }

                e.DrawFocusRectangle(); //This draws a focus rectangle around the item, its used to indicate the item selected
            }
        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void LinearSearch_Click(object sender, EventArgs e) //If the LinearSearch button is clicked
        {
            string searchTerm = SearchBox.Text.Trim(); //The string searchTerm becomes the text within the SearchBox, it trims any whitespace
            if (!string.IsNullOrEmpty(searchTerm)) //If the searchTerm is not empty
            {
                int foundIndex = -1; //I create integer foundIndex and give it value of -1
                for (int i = 0; i < carRegos.Count; i++) //This for loop iterates through the carRegos list to find a match
                {
                    if (carRegos[i].Equals(searchTerm, StringComparison.OrdinalIgnoreCase)) //If a match is found
                    {
                        foundIndex = i; //Update foundIndex value to matched index value
                        break; //Break out of the loop 
                    }
                }
                if (foundIndex != -1) //If match has been found, foundIndex not at value -1
                {
                    RegoList.SelectedIndex = foundIndex; //foundIndex value becomes SelectedIndex value
                    MessageBox.Show($"Found {searchTerm} at index: {foundIndex}"); //Present message box with the index of the searchTerm
                }
                else //If no match has been found
                {
                    MessageBox.Show($"Not found: {searchTerm}");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid rego");
            }
        }

        private int BinarySearchFunc(List<String> sortedList, string searchTerm) //This is the Binary Search Function. it takes the sortedList string, and searchTerm string as arguments
        {
            int left = 0; //I initialize a pointer left and give it value of 0
            int right = sortedList.Count - 1; //I initialize a pointer right and give it value of -1

            while (left <= right) //While left is less than or equal to right
            {
                int middle = left + (right - left) / 2; //I create int called middle, this loop calculates the middle of the index using average of left and right
                int comparison = string.Compare(sortedList[middle], searchTerm, StringComparison.OrdinalIgnoreCase); //This compares the string at the middle index and the searchTerm
                //The string.Compare method returns a value less than 0 if searchTerm is less than sortedList[middle], 0 if they are equal and a value greater than 0 if searchTerm is greater
                if (comparison == 0) //If the searchTerm matches the string at middle index
                {
                    return middle; //The method returns the middle index as the position where the search term was found
                }
                else if (comparison < 0) //The search term should be located in the left half of the search range, therefore the left pointer is updated to middle + 1
                {
                    left = middle + 1;
                }
                else //The search term should be located in the right half of the search range, therefore the right pointer is updated to middle - 1
                {
                    right = middle - 1;
                }
            }
            return -1; //If the loop completes without finding a match, return -1 to indicate the search was unsuccessfull
        }

        private void BinarySearch_Click(object sender, EventArgs e) //If the BinarySearch button is clicked
        {
            string searchTerm = SearchBox.Text.Trim(); //The string searchTerm becomes the text in the SearchBox
            if (!string.IsNullOrEmpty(searchTerm)) //If the searchTerm is not null or empty
            {
                int foundIndex = BinarySearchFunc(carRegos, searchTerm); //the int foundIndex becomes reusult of BinarySearchFunc function
                if (foundIndex != -1) //If foundIndex value (BinarySearch results) is not -1
                {
                    RegoList.SelectedIndex = foundIndex; //This sets the SelectedIndex of the RegoList to the foundIndex
                    MessageBox.Show($"Found {searchTerm} at index: {foundIndex}"); //Present results of search to user
                }
                else //Else, inform user the searchTerm was not found
                {
                    MessageBox.Show($"Not Found: {searchTerm}");
                }
            }
            else //If the searchTerm is NullOrEmpty
            {
                MessageBox.Show("Please enter a valid rego");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
    
        }
    }
}