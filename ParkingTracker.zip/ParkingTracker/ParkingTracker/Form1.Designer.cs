﻿namespace ParkingTracker
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OpenFile = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.SaveData = new System.Windows.Forms.Button();
            this.AddNew = new System.Windows.Forms.Button();
            this.DeleteExistingRego = new System.Windows.Forms.Button();
            this.RegoList = new System.Windows.Forms.ListBox();
            this.TagRego = new System.Windows.Forms.Button();
            this.DeleteAll = new System.Windows.Forms.Button();
            this.ModifyRegoTextBox = new System.Windows.Forms.TextBox();
            this.NewRegoTextBox = new System.Windows.Forms.TextBox();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.BinarySearch = new System.Windows.Forms.Button();
            this.LinearSearch = new System.Windows.Forms.Button();
            this.SaveAs = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OpenFile
            // 
            this.OpenFile.Location = new System.Drawing.Point(12, 12);
            this.OpenFile.Name = "OpenFile";
            this.OpenFile.Size = new System.Drawing.Size(75, 23);
            this.OpenFile.TabIndex = 1;
            this.OpenFile.Text = "Open File";
            this.OpenFile.UseVisualStyleBackColor = true;
            this.OpenFile.Click += new System.EventHandler(this.OpenFile_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UpdateButton.Location = new System.Drawing.Point(12, 366);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(123, 23);
            this.UpdateButton.TabIndex = 4;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // SaveData
            // 
            this.SaveData.Location = new System.Drawing.Point(12, 41);
            this.SaveData.Name = "SaveData";
            this.SaveData.Size = new System.Drawing.Size(75, 23);
            this.SaveData.TabIndex = 6;
            this.SaveData.Text = "Save Data";
            this.SaveData.UseVisualStyleBackColor = true;
            this.SaveData.Click += new System.EventHandler(this.SaveData_Click);
            // 
            // AddNew
            // 
            this.AddNew.Location = new System.Drawing.Point(12, 396);
            this.AddNew.Name = "AddNew";
            this.AddNew.Size = new System.Drawing.Size(123, 23);
            this.AddNew.TabIndex = 7;
            this.AddNew.Text = "Add New Rego";
            this.AddNew.UseVisualStyleBackColor = true;
            this.AddNew.Click += new System.EventHandler(this.AddNew_Click);
            // 
            // DeleteExistingRego
            // 
            this.DeleteExistingRego.Location = new System.Drawing.Point(12, 128);
            this.DeleteExistingRego.Name = "DeleteExistingRego";
            this.DeleteExistingRego.Size = new System.Drawing.Size(123, 23);
            this.DeleteExistingRego.TabIndex = 8;
            this.DeleteExistingRego.Text = "Delete Selected";
            this.DeleteExistingRego.UseVisualStyleBackColor = true;
            this.DeleteExistingRego.Click += new System.EventHandler(this.DeleteExistingRego_Click);
            // 
            // RegoList
            // 
            this.RegoList.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.RegoList.FormattingEnabled = true;
            this.RegoList.ItemHeight = 15;
            this.RegoList.Location = new System.Drawing.Point(158, 12);
            this.RegoList.Name = "RegoList";
            this.RegoList.Size = new System.Drawing.Size(459, 289);
            this.RegoList.TabIndex = 9;
            this.RegoList.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.RegoList_DrawItem);
            this.RegoList.SelectedIndexChanged += new System.EventHandler(this.RegoList_SelectedIndexChanged);
            this.RegoList.DoubleClick += new System.EventHandler(this.RegoList_DoubleClick);
            // 
            // TagRego
            // 
            this.TagRego.Location = new System.Drawing.Point(12, 157);
            this.TagRego.Name = "TagRego";
            this.TagRego.Size = new System.Drawing.Size(75, 23);
            this.TagRego.TabIndex = 10;
            this.TagRego.Text = "Tag Rego";
            this.TagRego.UseVisualStyleBackColor = true;
            this.TagRego.Click += new System.EventHandler(this.TagRego_Click);
            // 
            // DeleteAll
            // 
            this.DeleteAll.Location = new System.Drawing.Point(12, 99);
            this.DeleteAll.Name = "DeleteAll";
            this.DeleteAll.Size = new System.Drawing.Size(123, 23);
            this.DeleteAll.TabIndex = 11;
            this.DeleteAll.Text = "Delete All Regos";
            this.DeleteAll.UseVisualStyleBackColor = true;
            this.DeleteAll.Click += new System.EventHandler(this.DeleteAll_Click);
            // 
            // ModifyRegoTextBox
            // 
            this.ModifyRegoTextBox.Location = new System.Drawing.Point(158, 366);
            this.ModifyRegoTextBox.Name = "ModifyRegoTextBox";
            this.ModifyRegoTextBox.Size = new System.Drawing.Size(222, 23);
            this.ModifyRegoTextBox.TabIndex = 13;
            this.ModifyRegoTextBox.TextChanged += new System.EventHandler(this.ModifyRegoTextBox_TextChanged);
            // 
            // NewRegoTextBox
            // 
            this.NewRegoTextBox.Location = new System.Drawing.Point(158, 395);
            this.NewRegoTextBox.Name = "NewRegoTextBox";
            this.NewRegoTextBox.Size = new System.Drawing.Size(222, 23);
            this.NewRegoTextBox.TabIndex = 14;
            this.NewRegoTextBox.TextChanged += new System.EventHandler(this.NewRegoTextBox_TextChanged);
            // 
            // SearchBox
            // 
            this.SearchBox.Location = new System.Drawing.Point(548, 396);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(226, 23);
            this.SearchBox.TabIndex = 15;
            this.SearchBox.TextChanged += new System.EventHandler(this.SearchBox_TextChanged);
            // 
            // BinarySearch
            // 
            this.BinarySearch.Location = new System.Drawing.Point(675, 365);
            this.BinarySearch.Name = "BinarySearch";
            this.BinarySearch.Size = new System.Drawing.Size(99, 23);
            this.BinarySearch.TabIndex = 16;
            this.BinarySearch.Text = "Binary Search";
            this.BinarySearch.UseVisualStyleBackColor = true;
            this.BinarySearch.Click += new System.EventHandler(this.BinarySearch_Click);
            // 
            // LinearSearch
            // 
            this.LinearSearch.Location = new System.Drawing.Point(548, 365);
            this.LinearSearch.Name = "LinearSearch";
            this.LinearSearch.Size = new System.Drawing.Size(105, 23);
            this.LinearSearch.TabIndex = 17;
            this.LinearSearch.Text = "Linear Search";
            this.LinearSearch.UseVisualStyleBackColor = true;
            this.LinearSearch.Click += new System.EventHandler(this.LinearSearch_Click);
            // 
            // SaveAs
            // 
            this.SaveAs.Location = new System.Drawing.Point(12, 70);
            this.SaveAs.Name = "SaveAs";
            this.SaveAs.Size = new System.Drawing.Size(75, 23);
            this.SaveAs.TabIndex = 18;
            this.SaveAs.Text = "Save As";
            this.SaveAs.UseVisualStyleBackColor = true;
            this.SaveAs.Click += new System.EventHandler(this.SaveAs_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.SaveAs);
            this.Controls.Add(this.LinearSearch);
            this.Controls.Add(this.BinarySearch);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.NewRegoTextBox);
            this.Controls.Add(this.ModifyRegoTextBox);
            this.Controls.Add(this.DeleteAll);
            this.Controls.Add(this.TagRego);
            this.Controls.Add(this.RegoList);
            this.Controls.Add(this.DeleteExistingRego);
            this.Controls.Add(this.AddNew);
            this.Controls.Add(this.SaveData);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.OpenFile);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button OpenFile;
        private Button UpdateButton;
        private Button SaveData;
        private Button AddNew;
        private Button DeleteExistingRego;
        private ListBox RegoList;
        private Button TagRego;
        private Button DeleteAll;
        private TextBox ModifyRegoTextBox;
        private TextBox NewRegoTextBox;
        private TextBox SearchBox;
        private Button BinarySearch;
        private Button LinearSearch;
        private Button SaveAs;
    }
}